INSERT INTO jobs (title, description, requirements, location, salaryRange, status)
VALUES ('Software Engineer', 'Develop and maintain software solutions', 'Java, Spring', 'Remote', '50000-70000', 'open');
