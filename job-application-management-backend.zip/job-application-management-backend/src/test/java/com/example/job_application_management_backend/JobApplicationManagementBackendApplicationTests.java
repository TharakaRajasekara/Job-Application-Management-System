package com.example.job_application_management_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobApplicationManagementBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
