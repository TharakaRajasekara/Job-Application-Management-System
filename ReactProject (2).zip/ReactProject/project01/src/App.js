import React, { useState } from "react";
import JobForm from "./components/JobForm";
import JobList from "./components/JobList";
import './styles.css';  // Import the CSS file

const App = () => {
  const [jobs, setJobs] = useState([]);
  const [editingJob, setEditingJob] = useState(null);

  const saveJob = (jobData) => {
    if (editingJob) {
      setJobs(jobs.map((job) => (job === editingJob ? jobData : job)));
      setEditingJob(null);
    } else {
      setJobs([...jobs, jobData]);
    }
  };

  const editJob = (job) => {
    setEditingJob(job);
  };

  const toggleJobStatus = (job) => {
    setJobs(
      jobs.map((j) =>
        j === job ? { ...j, status: j.status === "open" ? "closed" : "open" } : j
      )
    );
  };

  return (
    <div>
      <h1>Job Application Management</h1>
      <JobForm onSave={saveJob} job={editingJob} />
      <JobList jobs={jobs} onEdit={editJob} onToggleStatus={toggleJobStatus} />
    </div>
  );
};

export default App;
