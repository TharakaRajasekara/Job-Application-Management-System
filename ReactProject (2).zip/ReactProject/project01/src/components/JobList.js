import React from "react";

const JobList = ({ jobs, onEdit, onToggleStatus }) => {
  return (
    <div>
      <h2>Job List</h2>
      {jobs.length === 0 ? (
        <p>No jobs available.</p>
      ) : (
        <ul>
          {jobs.map((job, index) => (
            <li key={index}>
              <h3>{job.title}</h3>
              <p>{job.description}</p>
              <p>Location: {job.location || "Not specified"}</p>
              <p>Salary: {job.salaryRange || "Not specified"}</p>
              <p>Status: {job.status}</p>
              <button onClick={() => onEdit(job)}>Edit</button>
              <button onClick={() => onToggleStatus(job)}>
                {job.status === "open" ? "Mark as Closed" : "Mark as Open"}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default JobList;
