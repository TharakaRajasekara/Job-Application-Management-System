import React, { useState } from "react";

const JobForm = ({ onSave, job }) => {
  const [title, setTitle] = useState(job?.title || "");
  const [description, setDescription] = useState(job?.description || "");
  const [requirements, setRequirements] = useState(job?.requirements || "");
  const [location, setLocation] = useState(job?.location || "");
  const [salaryRange, setSalaryRange] = useState(job?.salaryRange || "");
  const [status, setStatus] = useState(job?.status || "open");

  const handleSubmit = (e) => {
    e.preventDefault();
    const jobData = {
      title,
      description,
      requirements,
      location,
      salaryRange,
      status,
    };
    onSave(jobData);
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Job Title:</label>
        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} required />
      </div>
      <div>
        <label>Description:</label>
        <textarea value={description} onChange={(e) => setDescription(e.target.value)} required />
      </div>
      <div>
        <label>Requirements:</label>
        <textarea value={requirements} onChange={(e) => setRequirements(e.target.value)} />
      </div>
      <div>
        <label>Location:</label>
        <input type="text" value={location} onChange={(e) => setLocation(e.target.value)} />
      </div>
      <div>
        <label>Salary Range:</label>
        <input type="text" value={salaryRange} onChange={(e) => setSalaryRange(e.target.value)} />
      </div>
      <div>
        <label>Status:</label>
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="open">Open</option>
          <option value="closed">Closed</option>
        </select>
      </div>
      <button type="submit">Save Job</button>
    </form>
  );
};

export default JobForm;
